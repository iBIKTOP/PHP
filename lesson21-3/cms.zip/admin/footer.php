﻿			<!-- FOOTER START -->
			</div>
		
		</div>
		<!-- End Columns Row  -->
	

	</div><!-- End Div.Container -->
	
	<!-- Footer -->
	<footer class="footer">
		<div class="container">
			<div class="text-xs-center text-muted">
				Новостной сайт (с) 2016 | Админ панель
			</div>
		</div>
    </footer>
	<!-- Footer End -->

</body>
</html>