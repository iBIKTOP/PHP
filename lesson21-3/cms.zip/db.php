<?php 

	$connection = mysqli_connect("localhost", "root", "", "news_db");
	
?>