﻿	<!-- FOOTER START -->
	</div>
			<div class="col-md-3 hidden-sm-down">
				<img class="img-thumbnail" src="http://placehold.it/280x600">
			</div>
		
		</div>
		<!-- End Columns Row  -->
	

	</div><!-- End Div.Container -->
	
	<!-- Footer -->
	<footer class="footer">
		<div class="container">
			<div class="text-xs-center text-muted">
				Новостной сайт (с) 2016
			</div>
		</div>
    </footer>
	<!-- Footer End -->

</body>
</html>